#################
#  source code in 2 directories:
Rscripts/
pythonperlsrcs/


################
# example data after the RNA sequence mapping processing and configuration file config.GLiMMPS.txt in 
example/

